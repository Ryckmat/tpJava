package village;

public class Gaulois{
	
	private String nom;
	private EnumGenre genre;
	private Date date;
	private EnumStatus status;
	
	
	public Gaulois(String nom, Date dateDeNAissance, EnumGenre genre, EnumStatus  status ) {
		this.nom = nom;
		this.date.jour = dateDeNAissance.jour;
		this.date.mois = dateDeNAissance.mois;
		this.date.annee = dateDeNAissance.annee;
		this.genre = genre;
		this.status = status;
		
	}


	@Override
	public String toString() {
		return "Gaulois [nom=" + nom + ", genre=" + genre + ", date=" + date + ", status=" + status + "]";
	}


	public String getNom() {
		return nom;
	}


	public EnumGenre getGenre() {
		return genre;
	}


	public Date getDate() {
		return date;
	}


	public EnumStatus getStatus() {
		return status;
	}

}
