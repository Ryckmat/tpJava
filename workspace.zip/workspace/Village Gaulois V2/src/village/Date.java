package village;

public class Date {
	protected int jour;
	protected int mois;
	protected int annee;

}
