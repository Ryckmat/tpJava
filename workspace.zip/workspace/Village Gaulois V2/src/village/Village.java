package village;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.TreeSet;



public class Village{

	private ArrayList<Gaulois> v;
	
	public Village(Gaulois chef, Gaulois villageois) {
		this.v = new ArrayList<Gaulois>();
		v.add(chef);
		v.add(villageois);
	}
	
	public NavigableSet<Gaulois> getGauloisAge(){
		NavigableSet<Gaulois> ns = new TreeSet<>();
		for(Iterator<Gaulois> it= v.iterator();it.hasNext();){
			ns.add(it.next());
	}
		
		
	}

	

}
