package jeuRole;

import livre.Livre;

public class EntiteLivre{
	static protected Livre livre;
	
	public static void setLivre(Livre livre) {
		EntiteLivre.livre = livre;
		
	}

}
