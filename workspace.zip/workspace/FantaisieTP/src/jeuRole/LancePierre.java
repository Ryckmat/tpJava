package jeuRole;

public class LancePierre extends Arme {

	public LancePierre() {
		super("lance-pierre",10);
	}

}
