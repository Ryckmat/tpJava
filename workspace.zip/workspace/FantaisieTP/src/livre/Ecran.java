package livre;


public class Ecran implements Livre{

	public Ecran() {
		// TODO Auto-generated constructor stub
	}

	public void ecrire (String texte){
		System.out.println(texte);
	}

}
