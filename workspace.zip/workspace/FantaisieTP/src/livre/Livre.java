package livre;

public interface Livre {

	public void ecrire(String texte);
}
